# HR Data Visualization

This project demonstrates data visualization on HR salary and age data using Python (Matplotlib and Seaborn).

## Features
- Histograms, Boxplots, Scatterplots
- Correlation Heatmap
- Data Storytelling with Visuals

## How to Run
```bash
pip install -r requirements.txt
jupyter notebook notebooks/hr_visualization.ipynb
```
